/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbms_assignment;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author LENOVO
 */
 public class HashTable {
     public int bfr;

  private class ListNode {
     ArrayList<Integer> records = new ArrayList<Integer>(bfr);
     int hash;
     int ld;
  }

  private class Dir
  {
      int ind;
  }
  
  private Dir[] table;
  public ListNode[] localtable;
  public int gd;
  public int hashfunction=0;
  
  public HashTable()
  {
    localtable=new ListNode[2];
    ListNode temp=new ListNode();
    temp.hash=0;
    temp.ld=1;
    localtable[0]=temp;
    ListNode temp2=new ListNode();
    temp2.hash=1;
    temp2.ld=1;
    localtable[1]=temp2;
  } 
  
  public void Create_Dir(int size) 
  {
       table=new Dir[size];
       for(int i=0;i<size;i++)
       {
           Dir tempD=new Dir();
           table[i]=tempD;
           for(int j=0;j<localtable.length;j++)
           {
            int hashV = (int) (i%Math.pow(2,localtable[j].ld));
            if(localtable[j].hash==hashV)
            {
                table[i].ind=j;
                break;
            }
           }
       }
       return;
  }
    public String bin(int x,int n) 
    { 
    String s="";
    /* step 1 */
    for(int i=0;i<n;i++)
    {
        int b=x%2;
        x=x/2;
        s=b+s;
    }
    return s;
    } 
  public String dump() {
     //System.out.println(table.length);
     String o="";
     int[] mark=new int[localtable.length];
     for (int i = 0; i < table.length; i++) 
     {
        ListNode list=localtable[table[i].ind];
        if(mark[table[i].ind]!=1)
        {
        o+=(bin(list.hash,list.ld) + ":");
        mark[table[i].ind]=1;
        o+=(" "+list.records);
        o+="\n";
        }
     }
     return o;
  } 
  
  public void put(Object key) {
     int bucket = hash(key);
     //System.out.print(bucket);
     int localTP=table[bucket].ind;
     ListNode list=localtable[localTP];
     if(list.records.size()==bfr)
     {
       //System.out.print(list.ld+" "+(int)Math.sqrt(gd));
       if(list.ld==(int)Math.ceil(Math.log10(gd)/Math.log10(2)))
       {
           //System.out.println("YES");
           if(gd<hashfunction)
           {
            //System.out.print("YES "+gd+" "+hashfunction);
            Create_Dir(gd*2);
            gd=gd*2;
           }
           else
           {
           JOptionPane.showMessageDialog(null,"The Directory has reached its limit.Please choose a different Hash Function");
           return;
           }
       }
       if(resize(list.hash)==1)
       {bucket=hash(key);
       localTP=table[bucket].ind;
       list=localtable[localTP];
       JOptionPane.showMessageDialog(null,"Added New Bucket.");}
       else
       {
       JOptionPane.showMessageDialog(null,"The Directory has reached its limit.Please choose a different Hash Function");
       return;
       }
     }
     if(list.records.size()==bfr)
     {
         JOptionPane.showMessageDialog(null,"the bucket has overflown.Please Retype the value to split the buckets further.");
         localtable[localTP]=list;
     }
     else
     {
        list.records.add((Integer) key);
        localtable[localTP]=list;
     }
  }
  
  private int hash(Object key) {
     return ((Math.abs((int)key))%hashfunction)%gd;
  }
  
  private int hashL(int x,int index)
  {
      return (int)(x%(Math.pow(2,localtable[index].ld)));
  }
  
  public String search(int key){
      int hashV=hash(key);
      ListNode bucket=localtable[table[hashV].ind];
      for(int i=0;i<bucket.records.size();i++)
      {
      if(bucket.records.get(i)==key)
      {
          return this.bin(localtable[table[hashV].ind].hash,localtable[table[hashV].ind].ld);
      }
      }
      return ""+-1;
  }
  private int resize(int hashV) {
     if(hashV*2<hashfunction)
     {
     ListNode[] newtable = new ListNode[localtable.length+1];
     int newH=0;
     ListNode tempNode=new ListNode();
     int ld_changed=0;
     for (int i = 0; i < table.length; i++) {
           if(localtable[table[i].ind].hash==hashV)
           {
               if(ld_changed==0)
               {
                   localtable[table[i].ind].ld++;
                   ld_changed=1;
                   tempNode.ld=localtable[table[i].ind].ld;
               }
               int H=hashL(i,table[i].ind);
               if(H!=hashV)
               {
               newH=H;
               table[i].ind=localtable.length;
               }
          }
        }
     tempNode.hash=newH;
     newtable[localtable.length]=tempNode;
     for(int i=0;i<localtable.length;i++)
     {
     newtable[i]=localtable[i];
     if(localtable[i].hash==hashV)
     {
     for(int j=0;j<newtable[i].records.size();j++)
     {
         //System.out.println(newtable[i].records.get(j));
         if(hashL(hash(newtable[i].records.get(j)),i)!=hashV)
         {
         //System.out.println("Yes");
         newtable[localtable.length].records.add(newtable[i].records.get(j));
         newtable[i].records.remove(j);
         j--;
         }
     }
     }
     }
     localtable=newtable;
     return 1;
    }
     else
     {
     return 0;
     }
  }
}